<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <?php
            $title="Evo45 - HOME";
            include 'repetition.php';
            echo $head;
        ?>
    </head>
    <body>
        <?php echo $header;?>
        <div class="middle-container">
			<div class="title-container">
				<h1>Defina suas metas, não seus limites.</h1>
			</div>
		</div>
        <?php echo $footer;?>
    </body>
</html>